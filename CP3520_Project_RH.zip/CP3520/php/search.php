<?php
session_start();
include 'conn.php';

if (empty($_SESSION['username']) || empty($_SESSION['password'])) {
    print("Access to database denied");
} else {
    $username = $_SESSION['username'];
    $password = $_SESSION['password'];
    $type = $_SESSION['type'];

    if ($type == "admin") {
        include '../includes/aheader.html';
    } elseif ($type == "user") {
        include '../includes/uheader.html';
    }

    if (isset($_POST["searchButton"])) {
        $keyword = $_POST['keyword'];
        $choice = $_POST['choice'];

        $sql = null;

        if ($choice == "Doctor") {
            // Assuming "doctors" table has columns "sin" and "name"
            $sql = $mysqli->prepare("SELECT * FROM doctors WHERE sin LIKE ? OR name LIKE ?");
        } elseif ($choice == "Patient") {
            // Assuming "patients" table has columns "sin" and "name"
            $sql = $mysqli->prepare("SELECT * FROM patients WHERE sin LIKE ? OR name LIKE ?");
        } else {
            print("<p>Invalid search choice</p>");
        }

        if ($sql) {
            $keyword = '%' . $keyword . '%';
            $sql->bind_param('ss', $keyword, $keyword);
            $sql->execute();
            $result = $sql->get_result();

            if (!$result) {
                print("<p>Select query failed</p>");
            } else {
                if ($result->num_rows == 0) {
                    print("<p>No match found</p>");
                } else {
                    print("<h1>Results</h1><table>");
                    if ($choice == "Doctor" || $choice == "Patient") {
                        // Display additional columns for "Doctor" and "Patient"
                        print("<tr><th>SIN</th><th>Name</th></tr>");
                    } else {
                        // Default display for "Author", "Title", "Call"
                        print("<tr><th>Author</th><th>Title</th><th><b>Call Number</b></th></tr>");
                    }

                    while ($row = $result->fetch_object()) {
                        echo '<tr>';
                        if ($choice == "Doctor" || $choice == "Patient") {
                            echo '<td>' . $row->sin . '</td>';
                            echo '<td>' . $row->name . '</td>';
                        } else {
                            echo '<td>' . $row->author . '</td>';
                            echo '<td>' . $row->title . '</td>';
                            echo '<td>' . $row->callno . '</td>';
                        }
                        echo '</tr>';
                    }
                    print("</table>");
                }
            }
        }
    } else {
        include '../includes/searchForm.html';
        include '../includes/footer.html';
    }
}
$mysqli->close();
?>

