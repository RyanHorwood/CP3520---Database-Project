<?php
session_start();
include 'conn.php';

if (empty($_SESSION['username']) || empty($_SESSION['password']))
    print("Access to database denied");
else {
    $username = $_SESSION['username'];
    $password = $_SESSION['password'];
    $type = $_SESSION['type'];

    if ($type != "admin") {
        include '../includes/uheader.html';
        print("<p>Insufficient privileges to delete patients from the list.</p>");
    } else {
        include '../includes/bheader.html';

        if (isset($_POST["deletePatientButton"])) {
            $dpatient = $_POST['dpatient'];
            $count = count($dpatient);

            for ($i = 0; $i < $count; $i++) {
                $sql = $mysqli->prepare("DELETE FROM patients WHERE sin=?");
                $sql->bind_param('s', $dpatient[$i]);
                $sql->execute();
                if ($sql->errno)
                    print("Delete query failed");
            }
            if ($count == 1)
                print("<p>$count patient removed from the list.</p>");
            else
                print("<p>$count patients removed from the list.</p>");
        } else {
            $sql = "SELECT * FROM patients";
            $result = $mysqli->query($sql);
            if (!$result)
                print("<p>Select query failed</p>");
            else {
                if ($result->num_rows == 0)
                    print("<p>There are no patients in the list</p>");
                else {
                    print("<h1>Select patient(s) to remove from the list</h1>");
                    ?>

                    <form name="deletePatients" method="post" action="<?php $PHP_SELF?>">

                    <?php
                    print("<table><tr><th></th><th>SIN</th><th>Name</th></tr>\n");
                    while ($row = $result->fetch_object()) {
                        echo '<tr>';
                        $sin = $row->sin;
                        print("<td><input type=\"checkbox\" name=\"dpatient[]\" value=\"$sin\"></td>");
                        echo '<td>' . $row->sin . '</td>';
                        echo '<td>' . $row->pname . '</td>';
                        echo '</tr>';
                        print("\n");
                    }
                    print("</table><br />\n<input type=\"submit\" value=\"Delete selected patients\" name=\"deletePatientButton\"></form>");
                }
            }
        }
    }
    include '../includes/footer.html';
}
$mysqli->close();
?>

