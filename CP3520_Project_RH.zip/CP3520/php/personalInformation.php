<?php
session_start();
include 'conn.php';

if (empty($_SESSION['username']) || empty($_SESSION['password'])) {
    print("Access to database denied");
} else {
    $username = $_SESSION['username'];
    $password = $_SESSION['password'];
    $type = $_SESSION['type'];

    include '../includes/pheader.html';

    $sql = "SELECT patients.*, doctors.name 
            FROM users, patients, doctors, pair 
            WHERE users.username = patients.sin 
            AND patients.sin = pair.psin 
            AND pair.dsin = doctors.sin 
            AND users.username = '$username'"; // Add this condition

    $result = $mysqli->query($sql);

    if (!$result) {
        print("<p>Select query failed</p>");
    } else {
        if ($result->num_rows == 0) {
            print("<p>There is no patient information for the currently logged-in user</p>");
        } else {
            print("<h1>Personal Info</h1>");
            print("<form name='deletepatients' method='post' action='" . $_SERVER['PHP_SELF'] . "'>");

            print("<table><tr><th></th><th>SIN</th><th>Name</th><th>Age</th><th>Address</th><th>Primary Physician</th></tr>\n");

            while ($row = $result->fetch_object()) {
                echo '<tr>';
                echo '<td><input type="checkbox" name="dbook[]" value="' . $row->sin . '"></td>';
                echo '<td>' . $row->sin . '</td>';
                echo '<td>' . $row->pname . '</td>'; // Corrected from $row->pname
                echo '<td>' . $row->age . '</td>';
                echo '<td>' . $row->address . '</td>';
                echo '<td>' . $row->name . '</td>';
                echo '</tr>';
                print("\n");
            }
            print("</table>");
        }
    }

    include '../includes/footer.html';
}

$mysqli->close();
?>

