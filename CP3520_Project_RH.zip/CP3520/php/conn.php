<?php
	@$mysqli = new mysqli("localhost", "conn", "conn", "library");
?>
