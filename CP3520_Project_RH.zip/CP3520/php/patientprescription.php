<?php
session_start();
include 'conn.php';

if (empty($_SESSION['username']) || empty($_SESSION['password'])) {
    print("Access to database denied");
} else {
    $username = $_SESSION['username'];
    $password = $_SESSION['password'];
    $type = $_SESSION['type'];

    include '../includes/uheader.html';

    $sql = "SELECT DISTINCT prescribes.* FROM prescribes
            JOIN patients ON patients.sin = prescribes.patient_ssn
            JOIN users ON users.username = patients.sin
            WHERE users.username = '$username'";
    $result = $mysqli->query($sql);

    if (!$result) {
        print("<p>Select query failed</p>");
    } else {
        if ($result->num_rows == 0) {
            print("<p>There are no prescriptions</p>");
        } else {
            print("<h1>Your Prescriptions</h1>");
            print("<table><tr><th></th><th>Doctor SIN</th><th>Patient SIN</th><th>Drug Name</th><th>Quantity</th><th>Date</th></tr>\n");

            while ($row = $result->fetch_object()) {
                echo '<tr>';
                echo '<td><input type="checkbox" name="dbook[]" value="sin"></td>';
                echo '<td>' . $row->dsin . '</td>';
                echo '<td>' . $row->psin . '</td>';
                echo '<td>' . $row->drug . '</td>';
                echo '<td>' . $row->quantity . '</td>';
                echo '<td>' . $row->date . '</td>';
                echo '</tr>';
                print("\n");
            }
            print("</table>");
        }
    }

    include '../includes/footer.html';
}

$mysqli->close();
?>

