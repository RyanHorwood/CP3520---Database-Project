<?php
session_start();
include 'conn.php';

if (empty($_SESSION['username']) || empty($_SESSION['password'])) {
    print("Access to database denied");
} else {
    $username = $_SESSION['username'];
    $password = $_SESSION['password'];
    $type = $_SESSION['type'];

    include '../includes/eheader.html';

    $sql = "SELECT DISTINCT pr.* FROM prescribes pr
            JOIN doctors d ON pr.Doctor = d.SIN
            JOIN patients p ON pr.Patient = p.SIN";
    $result = $mysqli->query($sql);

    if (!$result) {
        print("<p>Select query failed</p>");
    } else {
        if ($result->num_rows == 0) {
            print("<p>There are no prescriptions</p>");
        } else {
            print("<h1>Prescriptions</h1>");
            print("<table><tr><th>Doctor SIN</th><th>Patient SIN</th><th>Drug</th><th>Quantity</th><th>Date</th></tr>\n");

            while ($row = $result->fetch_object()) {
                echo '<tr>';
                echo '<td>' . $row->Doctor . '</td>';
                echo '<td>' . $row->Patient . '</td>';
                echo '<td>' . $row->Drug . '</td>';
                echo '<td>' . $row->Quantity . '</td>';
                echo '<td>' . $row->Date . '</td>';
                echo '</tr>';
                print("\n");
            }
            print("</table>");
        }
    }

    include '../includes/footer.html';
}

$mysqli->close();
?>
