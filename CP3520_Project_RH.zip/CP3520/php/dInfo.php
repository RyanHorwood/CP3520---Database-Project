<?php
session_start();
include 'conn.php';

if (empty($_SESSION['username']) || empty($_SESSION['password'])) {
    print("Access to database denied");
} else {
    $username = $_SESSION['username'];
    $password = $_SESSION['password'];
    $type = $_SESSION['type'];

    include '../includes/dheader.html';

    $sql = "SELECT sin, name, specialty, experience FROM doctors";
    $result = $mysqli->query($sql);

    if (!$result) {
        print("<p>Select query failed</p>");
    } else {
        if ($result->num_rows == 0) {
            print("<p>There are no doctors in the list</p>");
        } else {
            print("<h1>List of Doctors</h1>");
            print("<table><tr><th>Name</th><th>Specialty</th><th>Experience</th></tr>\n");

            while ($row = $result->fetch_object()) {
                echo '<tr>';
                echo '<td>' . $row->name . '</td>';
                echo '<td>' . $row->specialty . '</td>';
                echo '<td>' . $row->experience . '</td>';
                echo '</tr>';
                print("\n");
            }
            print("</table>");
        }
    }

}

include '../includes/footer.html';

$mysqli->close();
?>

