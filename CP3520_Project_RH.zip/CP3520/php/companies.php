<?php
session_start();
include 'conn.php';

if (empty($_SESSION['username']) || empty($_SESSION['password'])) {
    print("Access to database denied");
} else {
    $username = $_SESSION['username'];
    $password = $_SESSION['password'];
    $type = $_SESSION['type'];

    if ($type != "pharmacy") {
        include '../includes/uheader.html';
        print("<p>Insufficient privileges to view contracts.</p>");
    } else {
        include '../includes/eheader.html';

        // Display all values in the 'company' table
        $companyQuery = "SELECT * FROM company";
        $resultCompany = $mysqli->query($companyQuery);

        if (!$resultCompany) {
            print("<p>Error fetching company data.</p>");
        } else {
            if ($resultCompany->num_rows > 0) {
                print("<h1>Company Data</h1>");
                print("<table><tr><th>Name</th><th>Phone</th></tr>\n");

                while ($row = $resultCompany->fetch_object()) {
                    echo '<tr>';
                    echo '<td>' . $row->Name . '</td>';
                    echo '<td>' . $row->Phone . '</td>';
                    echo '</tr>';
                }

                print("</table>");
            } else {
                print("<p>No company data found.</p>");
            }
        }

        include '../includes/footer.html';
    }
    $mysqli->close();
}
?>

