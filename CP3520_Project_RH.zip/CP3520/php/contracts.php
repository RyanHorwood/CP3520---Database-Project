<?php
session_start();
include 'conn.php';

if (empty($_SESSION['username']) || empty($_SESSION['password'])) {
    print("Access to database denied");
} else {
    $username = $_SESSION['username'];
    $password = $_SESSION['password'];
    $type = $_SESSION['type'];

    if ($type != "pharmacy") {
        include '../includes/uheader.html';
        print("<p>Insufficient privileges to view contracts.</p>");
    } else {
        include '../includes/eheader.html';

        // Display existing contracts for the pharmacy
        $contractsQuery = "SELECT * FROM contracts WHERE Pharmacy = ?";
        $getContracts = $mysqli->prepare($contractsQuery);
        $getContracts->bind_param('s', $username);
        $getContracts->execute();
        $resultContracts = $getContracts->get_result();

        if (!$resultContracts) {
            print("<p>Error fetching contracts.</p>");
        } else {
            if ($resultContracts->num_rows > 0) {
                print("<h1>Your Contracts</h1>");
                print("<table><tr><th>Company</th><th>Pharmacy</th><th>Start Date</th><th>End Date</th><th>Supervisor</th></tr>\n");

                while ($row = $resultContracts->fetch_object()) {
                    echo '<tr>';
                    echo '<td>' . $row->Company . '</td>';
                    echo '<td>' . $row->Pharmacy . '</td>';
                    echo '<td>' . $row->StartDate . '</td>';
                    echo '<td>' . $row->EndDate . '</td>';
                    echo '<td>' . $row->Supervisor . '</td>';
                    echo '</tr>';
                }

                print("</table>");
            } else {
                print("<p>No contracts found.</p>");
            }
        }

        include '../includes/footer.html';
    }
    $mysqli->close();
}
?>

