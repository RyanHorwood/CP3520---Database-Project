<?php
session_start();
include 'conn.php';

if (empty($_SESSION['username']) || empty($_SESSION['password'])) {
    print("Access to database denied");
} else {
    $username = $_SESSION['username'];
    $password = $_SESSION['password'];
    $type = $_SESSION['type'];

    if ($type != "admin") {
        include '../includes/uheader.html';
        print("<p>Insufficient privileges to prescribe drugs.</p>");
    } else {
        include '../includes/bheader.html';

        // Handle prescription form submission
        if (isset($_POST["prescribeButton"])) {
            $Patient = $_POST['Patient'];
            $Drug = $_POST['Drug'];
            $Quantity = $_POST['Quantity'];
            $Date = $_POST['Date'];

            // Check if the drug is already prescribed to the patient on the same day
            $checkExisting = $mysqli->prepare("SELECT * FROM prescribes WHERE Doctor = ? AND Patient = ? AND Drug = ? AND Date = ?");
            $checkExisting->bind_param('ssss', $username, $Patient, $Drug, $Date);
            $checkExisting->execute();
            $resultExisting = $checkExisting->get_result();

            if ($resultExisting->num_rows > 0) {
                print("<p>The drug has already been prescribed to the patient on the same day.</p>");
            } else {
                // Insert prescription information into the 'prescribes' table
                $insertPrescription = $mysqli->prepare("INSERT INTO prescribes (Doctor, Patient, Drug, Quantity, Date) VALUES (?, ?, ?, ?, ?)");
                $insertPrescription->bind_param('sssss', $username, $Patient, $Drug, $Quantity, $Date);
                $insertPrescription->execute();

                if ($insertPrescription->errno) {
                    print("<p>Prescription failed to be added.</p>");
                } else {
                    print("<p>Prescription added successfully.</p>");
                }
            }
        }

// Display existing prescriptions for the doctor
$prescriptionsQuery = "SELECT DISTINCT pr.*, d.name AS Doctor, p.sin AS PatientSIN, p.pname AS Patient, dr.Drug AS Drug FROM prescribes pr
                        JOIN doctors d ON pr.Doctor = d.sin
                        JOIN patients p ON pr.Patient = p.sin
                        JOIN drugs dr ON pr.Drug = dr.Drug
                        WHERE pr.Doctor = ?";

$getPrescriptions = $mysqli->prepare($prescriptionsQuery);
$getPrescriptions->bind_param('s', $username);
$getPrescriptions->execute();
$resultPrescriptions = $getPrescriptions->get_result();

if (!$resultPrescriptions) {
    print("<p>Error fetching prescriptions.</p>");
} else {
    if ($resultPrescriptions->num_rows > 0) {
        print("<h1>Your Prescriptions</h1>");
        print("<table><tr><th>Patient SIN</th><th>Patient</th><th>Drug</th><th>Quantity</th><th>Date</th></tr>\n");

        while ($row = $resultPrescriptions->fetch_object()) {
            echo '<tr>';
            echo '<td>' . $row->PatientSIN . '</td>';
            echo '<td>' . $row->Patient . '</td>';
            echo '<td>' . $row->Drug . '</td>';
            echo '<td>' . $row->Quantity . '</td>';
            echo '<td>' . $row->Date . '</td>';
            echo '</tr>';
        }

        print("</table>");
    } else {
        print("<p>No prescriptions found.</p>");
    }
}

        // Prescription form
        ?>
        <h1>Prescribe Drug</h1>
        <form name="prescribeForm" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <label for="Patient">Patient:</label>
            <select name="Patient" required>
                <?php
                // Fetch patients from the 'patients' table
                $patientsQuery = "SELECT * FROM patients";
                $resultPatients = $mysqli->query($patientsQuery);
                while ($patient = $resultPatients->fetch_assoc()) {
                    echo "<option value='" . $patient['sin'] . "'>" . $patient['sin'] . "</option>";
                }
                ?>
            </select><br>

            <label for="Drug">Drug:</label>
            <select name="Drug" required>
                <?php
                // Fetch drugs from the 'drugs' table
                $drugsQuery = "SELECT * FROM drugs";
                $resultDrugs = $mysqli->query($drugsQuery);
                while ($drug = $resultDrugs->fetch_assoc()) {
                    echo "<option value='" . $drug['Drug'] . "'>" . $drug['Drug'] . "</option>";
                }
                ?>
            </select><br>

            <label for="Quantity">Quantity:</label>
            <input type="number" name="Quantity" required><br>

            <label for="Date">Prescription Date:</label>
            <input type="date" name="Date" required><br>

            <input type="submit" value="Prescribe" name="prescribeButton">
        </form>
        <?php
    }
    include '../includes/footer.html';
}

$mysqli->close();
?>

