<?php
session_start();
include 'conn.php';

if (empty($_SESSION['username']) || empty($_SESSION['password'])) {
    print("Access to database denied");
} else {
    $username = $_SESSION['username'];
    $password = $_SESSION['password'];
    $type = $_SESSION['type'];

    if ($type != "pharmacy") {
        include '../includes/uheader.html';
        print("<p>Insufficient privileges to view contracts.</p>");
    } else {
        include '../includes/eheader.html';

        // Display all values in the 'sells' table
        $sellsQuery = "SELECT * FROM sells";
        $resultSells = $mysqli->query($sellsQuery);

        if (!$resultSells) {
            print("<p>Error fetching sells data.</p>");
        } else {
            if ($resultSells->num_rows > 0) {
                print("<h1>Sells Data</h1>");
                print("<table><tr><th>Drug Name</th><th>Pharmacy</th><th>Price</th></tr>\n");

                while ($row = $resultSells->fetch_object()) {
                    echo '<tr>';
                    echo '<td>' . $row->DrugName . '</td>';
                    echo '<td>' . $row->Pharmacy . '</td>';
                    echo '<td>' . $row->Price . '</td>';
                    echo '</tr>';
                }

                print("</table>");
            } else {
                print("<p>No sells data found.</p>");
            }
        }

        include '../includes/footer.html';
    }
    $mysqli->close();
}
?>

