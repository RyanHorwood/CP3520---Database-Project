Login as root to mysql

Created database library. Logout.

Run: mysql -u root -p library < library.sql

Login as root to mysql, there should be three tables in db.

Create user:

create user 'conn'@'localhost' identified by 'conn';
flush privileges;
grant select, update, insert, delete on library.* to 'conn'@'localhost';
flush privileges;

Logout and try to login as conn.
